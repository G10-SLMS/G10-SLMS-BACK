<?php

use App\Http\Controllers\AttachmentController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\LeaveHistoryController;
use App\Http\Controllers\LeaveTypeController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SocialAuthController;
use App\Http\Controllers\LeaveRequestController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserImportController;
use App\Http\Controllers\CalendarController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Public routes
Route::get('/default-avatars', [AuthController::class, 'getDefaultAvatars']);

// Admin + Educator routes (management access, but NOT destructive actions)
Route::middleware(['auth:sanctum', 'role:admin,educator'])->group(function () {
    Route::get('/users', [UserController::class, 'index']);
    Route::post('/users', [UserController::class, 'store']);
    Route::put('/users/{user}', [UserController::class, 'update']);
    Route::get('/users/import/template', [UserImportController::class, 'template']);
    Route::post('/users/import', [UserImportController::class, 'import']);
    Route::post('/admin/default-avatars', [AuthController::class, 'uploadDefaultAvatar']);
});

// Admin-only routes (destructive actions stay restricted to admin)
Route::middleware(['auth:sanctum', 'admin'])->group(function () {
    Route::delete('/users/{user}', [UserController::class, 'destroy']);
    Route::patch('/users/{user}/status', [UserController::class, 'toggleStatus']);
    Route::post('/users/bulk-delete', [UserController::class, 'bulkDestroy']);
    Route::patch('/users/bulk-status', [UserController::class, 'bulkToggleStatus']);
    Route::patch('/users/scope-status', [UserController::class, 'toggleStatusByScope']);
});

// Authentication routes (Sanctum)
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Authentication routes (sanctum) -> forgot password
Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/reset-password', [AuthController::class, 'resetPassword']);

// Social login (Google / GitHub)
Route::middleware('cors')->group(function () {
    Route::get('/auth/{provider}/redirect', [SocialAuthController::class, 'redirect'])
        ->whereIn('provider', ['google', 'github']);
    Route::post('/auth/{provider}', [SocialAuthController::class, 'callback'])
        ->whereIn('provider', ['google', 'github']);
});

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/profile', [AuthController::class, 'profile']);
    Route::put('/profile', [AuthController::class, 'updateProfile']);
    Route::get('/calendar-events', [CalendarController::class, 'index']);

    // Notifications: Student/Educator/Admin (each sees only their own)
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::patch('/notifications/{notification}/read', [NotificationController::class, 'markAsRead']);
    Route::post('/notifications/read-all', [NotificationController::class, 'markAllAsRead']);

    // Student only
    Route::middleware('role:student')->group(function () {
        Route::post('/leave-requests', [LeaveRequestController::class, 'store']);
        Route::delete('/leave-requests/{leaveRequest}', [LeaveRequestController::class, 'destroy']);
        Route::post('/leave-requests/{leaveRequest}/attachments', [AttachmentController::class, 'store'])
            ->name('leave-requests.attachments.store');
    });

    // Update leave request (Student: own, Educator/Admin: any with status)
    Route::put('/leave-requests/{leaveRequest}', [LeaveRequestController::class, 'update']);

    // Educator: own assigned students only (not the full user directory)
    Route::middleware('role:educator')->group(function () {
        Route::get('/educator/students', [UserController::class, 'assignedStudents']);
    });

    // Student Directory: all students grouped by generation & class (Admin/Educator)
    Route::middleware('role:admin,educator')->group(function () {
        Route::get('/students/directory', [UserController::class, 'directory']);
    });

    // Shared: Student/Educator/Admin
    Route::get('/leave-requests', [LeaveRequestController::class, 'index']);
    Route::get('/leave-requests/stats', [LeaveRequestController::class, 'stats']);
    Route::get('/leave-requests/{leaveRequest}', [LeaveRequestController::class, 'show']);

    // Download attachment
    Route::get('/attachments/{attachment}/download', [LeaveRequestController::class, 'downloadAttachment'])->middleware('auth:sanctum');

    // Comment routes
    Route::get('/comments', [CommentController::class, 'index']);
    Route::post('/comments', [CommentController::class, 'store']);
    Route::get('/comments/{comment}', [CommentController::class, 'show']);
    Route::put('/comments/{comment}', [CommentController::class, 'update']);
    Route::delete('/comments/{comment}', [CommentController::class, 'destroy']);

    // Student Leave History
    Route::middleware('role:student')->group(function () {
        Route::get('/leave-history', [LeaveHistoryController::class, 'index']);
        Route::get('/leave-history/{id}', [LeaveHistoryController::class, 'show']);
    });

    // Reports Dashboard: Admin (org-wide) / Educator (own students only)
    Route::middleware('role:admin,educator')->group(function () {
        Route::get('/reports/summary', [ReportController::class, 'summary']);
    });
});

// Leave Type API
Route::get('/leave-types', [LeaveTypeController::class, 'index']);
Route::get('/leave-types/{id}', [LeaveTypeController::class, 'show']);

Route::middleware(['auth:sanctum', 'role:admin,student,educator'])->group(function () {
    Route::post('/leave-types', [LeaveTypeController::class, 'store']);
    Route::put('/leave-types/{leaveType}', [LeaveTypeController::class, 'update']);
});

// Deleting a leave type is destructive and stays admin-only.
Route::middleware(['auth:sanctum', 'admin'])->group(function () {
    Route::delete('/leave-types/{leaveType}', [LeaveTypeController::class, 'destroy']);
});
