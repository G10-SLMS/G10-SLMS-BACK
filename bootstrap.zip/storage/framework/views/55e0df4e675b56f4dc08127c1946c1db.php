<?php echo e($slot); ?>

<?php /**PATH C:\Users\REAKSMEY.SAN\Desktop\VC2\G10-SLMS-BACK\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>