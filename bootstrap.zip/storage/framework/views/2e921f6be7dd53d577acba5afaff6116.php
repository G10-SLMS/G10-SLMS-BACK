<table class="panel" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="panel-content">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="panel-item">
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
</table>

<?php /**PATH C:\Users\REAKSMEY.SAN\Desktop\VC2\G10-SLMS-BACK\resources\views/vendor/mail/html/panel.blade.php ENDPATH**/ ?>