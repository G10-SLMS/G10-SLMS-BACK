<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\REAKSMEY.SAN\Desktop\VC2\G10-SLMS-BACK\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>