<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Avatar extends Model
{

    protected $fillable = [
        'filename',
        'path',
        'is_default',
        'usage_count',
        'gender',
    ];

    protected $appends = ['url'];

    protected function casts(): array
    {
        return [
            'is_default' => 'boolean',
        ];
    }

    protected function url(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->path ? asset($this->path) : null,
        );
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function scopeSelectable(Builder $query): Builder
    {
        return $query->where('is_default', true);
    }

    public function scopeForGender(Builder $query, ?string $gender): Builder
    {
        return $gender ? $query->where('gender', $gender) : $query;
    }

    public static function fallbackFor(?string $gender): ?self
    {
        if ($gender) {
            $fallback = static::where('filename', "default_profile_{$gender}.jpg")->first();

            if ($fallback) {
                return $fallback;
            }
        }

        return static::selectable()->forGender($gender)->inRandomOrder()->first()
            ?? static::selectable()->inRandomOrder()->first();
    }
}
